package com.example.outbox.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 对应 application.yml 中 outbox.publisher.* 配置项。
 */
@Component
@ConfigurationProperties(prefix = "outbox.publisher")
public class OutboxPublisherProperties {

    /** 每次轮询任务的时间间隔（毫秒） */
    private long pollIntervalMs = 1000;

    /** 每批最多取多少条待发送消息 */
    private int batchSize = 50;

    /** 单条消息最大重试次数，超过后标记为 FAILED */
    private int maxRetryTimes = 5;

    /** 已发送消息保留多少天后可被清理 */
    private int sentRetentionDays = 7;

    public long getPollIntervalMs() {
        return pollIntervalMs;
    }

    public void setPollIntervalMs(long pollIntervalMs) {
        this.pollIntervalMs = pollIntervalMs;
    }

    public int getBatchSize() {
        return batchSize;
    }

    public void setBatchSize(int batchSize) {
        this.batchSize = batchSize;
    }

    public int getMaxRetryTimes() {
        return maxRetryTimes;
    }

    public void setMaxRetryTimes(int maxRetryTimes) {
        this.maxRetryTimes = maxRetryTimes;
    }

    public int getSentRetentionDays() {
        return sentRetentionDays;
    }

    public void setSentRetentionDays(int sentRetentionDays) {
        this.sentRetentionDays = sentRetentionDays;
    }
}
