package com.example.outbox.mq;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.rocketmq.spring.annotation.ConsumeMode;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.apache.rocketmq.spring.support.RocketMQHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 消费端示例：演示基于 message_id（KEYS）的幂等处理。
 * <p>
 * 生产环境应把"已处理消息表"落库（唯一索引 message_id），
 * 而不是像这里一样用内存 Set——仅用于演示幂等思路，进程重启后会丢失去重记录。
 */
@Component
@RocketMQMessageListener(
        topic = "order-event-topic",
        consumerGroup = "outbox-demo-consumer-group",
        consumeMode = ConsumeMode.CONCURRENTLY
)
public class OrderEventConsumer implements RocketMQListener<Message<String>> {

    private static final Logger log = LoggerFactory.getLogger(OrderEventConsumer.class);

    // 仅作演示，生产环境请替换为数据库唯一索引 + 插入去重
    private final Set<String> processedMessageIds = ConcurrentHashMap.newKeySet();

    private final ObjectMapper objectMapper;

    @Autowired
    public OrderEventConsumer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public void onMessage(Message<String> message) {
        Object keysObj = message.getHeaders().get(RocketMQHeaders.KEYS);
        String messageId = keysObj == null ? null : keysObj.toString();

        if (messageId != null && !processedMessageIds.add(messageId)) {
            log.info("消息已处理过，幂等跳过: messageId={}", messageId);
            return;
        }

        try {
            OutboxEventPayload payload =
                    objectMapper.readValue(message.getPayload(), OutboxEventPayload.class);
            log.info("消费订单事件: messageId={}, orderNo={}, status={}",
                    messageId, payload.getOrderNo(), payload.getStatus());

            // TODO: 在此处理具体业务逻辑（如更新下游系统、发送通知等）
        } catch (Exception e) {
            if (messageId != null) {
                // 处理失败时移除去重标记，允许下次重投时重新处理
                processedMessageIds.remove(messageId);
            }
            throw new RuntimeException("消费订单事件失败", e);
        }
    }
}
