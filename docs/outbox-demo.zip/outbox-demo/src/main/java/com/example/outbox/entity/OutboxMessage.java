package com.example.outbox.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Outbox 事件表实体：与业务表同库、同事务写入，
 * 是 Outbox 模式保证一致性的核心。
 * <p>
 * 状态流转：PENDING -&gt; SENT
 * 或：PENDING -&gt; (发送失败，retryCount++) -&gt; PENDING -&gt; ... -&gt; FAILED（超过最大重试次数）
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "outbox_message")
public class OutboxMessage {

    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_SENT = "SENT";
    public static final String STATUS_FAILED = "FAILED";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** 全局唯一消息 ID，写入消息 KEYS，供消费端幂等去重 */
    @Column(name = "message_id", nullable = false, unique = true, length = 64)
    private String messageId;

    /** 聚合根类型，如 Order */
    @Column(name = "aggregate_type", nullable = false, length = 64)
    private String aggregateType;

    /** 聚合根 ID，如订单号 */
    @Column(name = "aggregate_id", nullable = false, length = 64)
    private String aggregateId;

    /** 事件类型，如 OrderPaid */
    @Column(name = "event_type", nullable = false, length = 64)
    private String eventType;

    /** 目标 RocketMQ Topic */
    @Column(name = "topic", nullable = false, length = 64)
    private String topic;

    /** 目标 RocketMQ Tag，可为空 */
    @Column(name = "tag", length = 64)
    private String tag;

    /** 消息体，JSON 格式 */
    @Lob
    @Column(name = "payload", nullable = false)
    private String payload;

    @Column(name = "status", nullable = false, length = 16)
    private String status = STATUS_PENDING;

    @Column(name = "retry_count", nullable = false)
    private Integer retryCount = 0;

    @Column(name = "next_retry_at")
    private LocalDateTime nextRetryAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "sent_at")
    private LocalDateTime sentAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }
}
