package com.example.outbox.scheduler;

import com.example.outbox.config.OutboxPublisherProperties;
import com.example.outbox.entity.OutboxMessage;
import com.example.outbox.repository.OutboxRepository;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 轮询发布器（Polling Publisher）：
 * 定时扫描 outbox 表中 PENDING 的记录，逐条投递到 RocketMQ，
 * 成功则标记 SENT，失败则计数重试，超过阈值标记 FAILED。
 * <p>
 * 这是 Outbox 模式"异步投递"部分的具体实现；
 * 与之对应的另一种方式是 CDC 订阅 binlog（如 Debezium），
 * 详见 outbox模式事务流程说明.md。
 */
@Component
public class OutboxPublisher {

    private static final Logger log = LoggerFactory.getLogger(OutboxPublisher.class);

    private final OutboxRepository outboxRepository;
    private final RocketMQTemplate rocketMQTemplate;
    private final OutboxPublisherProperties properties;

    @Autowired
    public OutboxPublisher(OutboxRepository outboxRepository,
                            RocketMQTemplate rocketMQTemplate,
                            OutboxPublisherProperties properties) {
        this.outboxRepository = outboxRepository;
        this.rocketMQTemplate = rocketMQTemplate;
        this.properties = properties;
    }

    @Scheduled(fixedDelayString = "${outbox.publisher.poll-interval-ms:1000}")
    public void publishPendingMessages() {
        Pageable pageable = PageRequest.of(0, properties.getBatchSize());
        List<OutboxMessage> pendingList =
                outboxRepository.findByStatusOrderByCreatedAtAsc(OutboxMessage.STATUS_PENDING, pageable);

        if (pendingList.isEmpty()) {
            return;
        }

        for (OutboxMessage outboxMessage : pendingList) {
            publishOne(outboxMessage);
        }
    }

    /**
     * 单条消息的发送与状态更新。
     * 注：这里不加 @Transactional——它是被同类内的 publishPendingMessages
     * 通过 this 直接调用的（Spring AOP 自调用不会走代理，注解会静默失效），
     * 而每个分支里也只有一次 save()，Spring Data JPA 的 save 本身已在自己的
     * 事务里执行，不需要额外包一层。
     */
    public void publishOne(OutboxMessage outboxMessage) {
        String destination = outboxMessage.getTag() == null
                ? outboxMessage.getTopic()
                : outboxMessage.getTopic() + ":" + outboxMessage.getTag();

        try {
            // 用 message_id 作为 KEYS，供消费端幂等去重
            Message<String> message = MessageBuilder.withPayload(outboxMessage.getPayload())
                    .setHeader(org.apache.rocketmq.spring.support.RocketMQHeaders.KEYS,
                            outboxMessage.getMessageId())
                    .build();

            rocketMQTemplate.syncSend(destination, message);

            outboxMessage.setStatus(OutboxMessage.STATUS_SENT);
            outboxMessage.setSentAt(LocalDateTime.now());
            outboxRepository.save(outboxMessage);

            log.info("outbox 消息发送成功: messageId={}, topic={}", outboxMessage.getMessageId(), destination);
        } catch (Exception e) {
            handleFailure(outboxMessage, e);
        }
    }

    private void handleFailure(OutboxMessage outboxMessage, Exception e) {
        int retryCount = outboxMessage.getRetryCount() + 1;
        outboxMessage.setRetryCount(retryCount);

        if (retryCount >= properties.getMaxRetryTimes()) {
            outboxMessage.setStatus(OutboxMessage.STATUS_FAILED);
            log.error("outbox 消息发送失败，已达最大重试次数，标记 FAILED: messageId={}",
                    outboxMessage.getMessageId(), e);
        } else {
            // 简单退避：下次轮询自然会再次捞取到（仍为 PENDING）
            outboxMessage.setNextRetryAt(LocalDateTime.now().plusSeconds(retryCount * 5L));
            log.warn("outbox 消息发送失败，第 {} 次重试将在稍后进行: messageId={}",
                    retryCount, outboxMessage.getMessageId(), e);
        }
        outboxRepository.save(outboxMessage);
    }
}
