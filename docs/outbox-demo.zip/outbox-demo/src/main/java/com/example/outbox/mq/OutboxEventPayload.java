package com.example.outbox.mq;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 事件消息体，序列化为 JSON 后存入 outbox_message.payload，
 * 也是最终发到 RocketMQ 的消息内容。
 */
public class OutboxEventPayload implements Serializable {

    private static final long serialVersionUID = 1L;

    private String orderNo;
    private BigDecimal amount;
    private String status;

    public OutboxEventPayload() {
    }

    public OutboxEventPayload(String orderNo, BigDecimal amount, String status) {
        this.orderNo = orderNo;
        this.amount = amount;
        this.status = status;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
