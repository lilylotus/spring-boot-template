package com.example.outbox.controller;

import com.example.outbox.entity.Order;
import com.example.outbox.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * 演示用接口：触发创建订单 / 支付订单，
 * 观察 outbox_message 表写入与 RocketMQ 投递情况。
 */
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    @Autowired
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping
    public Order create(@RequestParam(defaultValue = "99.00") BigDecimal amount) {
        return orderService.createOrder(amount);
    }

    @PostMapping("/{orderNo}/pay")
    public Order pay(@PathVariable String orderNo) {
        return orderService.payOrder(orderNo);
    }
}
