package com.example.outbox.repository;

import com.example.outbox.entity.OutboxMessage;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OutboxRepository extends JpaRepository<OutboxMessage, Long> {

    /**
     * 按状态查询待发送消息，按创建时间升序（先进先出），
     * 供 OutboxPublisher 定时批量拉取。
     */
    List<OutboxMessage> findByStatusOrderByCreatedAtAsc(String status, Pageable pageable);
}
