package com.example.outbox.service;

import com.example.outbox.entity.Order;
import com.example.outbox.entity.OutboxMessage;
import com.example.outbox.mq.OutboxEventPayload;
import com.example.outbox.repository.OrderRepository;
import com.example.outbox.repository.OutboxRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Outbox 模式的核心演示：
 * 业务表写入和 outbox 表写入放在同一个本地事务里，
 * 保证「订单状态变更」与「待发布事件」的原子性。
 */
@Service
public class OrderService {

    private static final String TOPIC_ORDER_EVENT = "order-event-topic";

    private final OrderRepository orderRepository;
    private final OutboxRepository outboxRepository;
    private final ObjectMapper objectMapper;

    @Autowired
    public OrderService(OrderRepository orderRepository,
                         OutboxRepository outboxRepository,
                         ObjectMapper objectMapper) {
        this.orderRepository = orderRepository;
        this.outboxRepository = outboxRepository;
        this.objectMapper = objectMapper;
    }

    /**
     * 创建订单：写业务表 + 写 outbox 表，同一事务。
     */
    @Transactional
    public Order createOrder(BigDecimal amount) {
        Order order = new Order();
        order.setOrderNo(generateOrderNo());
        order.setAmount(amount);
        order.setStatus(Order.STATUS_CREATED);
        orderRepository.save(order);

        saveOutboxEvent(order, "OrderCreated");
        return order;
    }

    /**
     * 支付订单：更新订单状态 + 写 outbox 表，同一事务。
     * 这是 Outbox 模式最典型的场景——
     * 状态变更和"要通知下游"这两件事，要么一起成功，要么一起失败。
     */
    @Transactional
    public Order payOrder(String orderNo) {
        Order order = orderRepository.findByOrderNo(orderNo)
                .orElseThrow(() -> new IllegalArgumentException("订单不存在: " + orderNo));

        order.setStatus(Order.STATUS_PAID);
        orderRepository.save(order);

        saveOutboxEvent(order, "OrderPaid");
        return order;
    }

    private void saveOutboxEvent(Order order, String eventType) {
        try {
            OutboxEventPayload payload = new OutboxEventPayload(
                    order.getOrderNo(), order.getAmount(), order.getStatus());

            OutboxMessage message = new OutboxMessage();
            message.setMessageId(UUID.randomUUID().toString().replace("-", ""));
            message.setAggregateType("Order");
            message.setAggregateId(order.getOrderNo());
            message.setEventType(eventType);
            message.setTopic(TOPIC_ORDER_EVENT);
            message.setTag(eventType);
            message.setPayload(objectMapper.writeValueAsString(payload));

            outboxRepository.save(message);
        } catch (Exception e) {
            // 序列化异常等应导致事务回滚，与业务变更保持一致
            throw new IllegalStateException("构造 outbox 事件失败", e);
        }
    }

    private String generateOrderNo() {
        return "ORD" + System.currentTimeMillis()
                + ThreadLocalRandom.current().nextInt(100, 999);
    }
}
