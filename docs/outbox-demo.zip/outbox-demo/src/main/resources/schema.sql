-- ========================================================
-- Outbox 模式示例建表脚本
-- 业务表 orders + 事件表 outbox_message 必须放在同一个数据库、
-- 同一个事务里写入，这是 Outbox 模式成立的前提。
-- ========================================================

CREATE DATABASE IF NOT EXISTS outbox_demo DEFAULT CHARACTER SET utf8mb4;
USE outbox_demo;

-- 业务表：订单
CREATE TABLE IF NOT EXISTS `orders` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_no`   VARCHAR(64)  NOT NULL COMMENT '订单号',
    `amount`     DECIMAL(18,2) NOT NULL COMMENT '订单金额',
    `status`     VARCHAR(32)  NOT NULL COMMENT '订单状态：CREATED / PAID / CANCELLED',
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- Outbox 表：待发布的领域事件
-- 必须和业务表同库，才能利用同一个本地事务保证原子性
CREATE TABLE IF NOT EXISTS `outbox_message` (
    `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `message_id`    VARCHAR(64)  NOT NULL COMMENT '全局唯一消息ID，供消费端幂等去重',
    `aggregate_type` VARCHAR(64) NOT NULL COMMENT '聚合根类型，如 Order',
    `aggregate_id`  VARCHAR(64)  NOT NULL COMMENT '聚合根ID，如订单号',
    `event_type`    VARCHAR(64)  NOT NULL COMMENT '事件类型，如 OrderPaid',
    `topic`         VARCHAR(64)  NOT NULL COMMENT '目标 RocketMQ Topic',
    `tag`           VARCHAR(64)  DEFAULT NULL COMMENT '目标 RocketMQ Tag',
    `payload`       TEXT         NOT NULL COMMENT '消息体，JSON 格式',
    `status`        VARCHAR(16)  NOT NULL DEFAULT 'PENDING' COMMENT 'PENDING / SENT / FAILED',
    `retry_count`   INT          NOT NULL DEFAULT 0 COMMENT '已重试次数',
    `next_retry_at` DATETIME     DEFAULT NULL COMMENT '下次可重试时间，用于失败退避',
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `sent_at`       DATETIME     DEFAULT NULL COMMENT '成功发送时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_message_id` (`message_id`),
    KEY `idx_status_created` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Outbox 事件表';
